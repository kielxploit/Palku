import { Card } from "@/components/ui/card";

export const About = () => {
  return (
    <section className="py-20 px-4" id="about">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-center mb-12 md:mb-16 bg-gradient-to-r from-foreground to-primary bg-clip-text text-transparent">
          About Palku
        </h2>

        <Card className="p-8 md:p-12 bg-card/50 backdrop-blur border-2 border-primary/30 max-w-4xl mx-auto">
          <div className="space-y-6 text-muted-foreground leading-relaxed">
            <p className="text-lg">
              Palku was built with one mission — to make link bypassing effortless, fast, and reliable right inside Discord. We understand how frustrating it can be to go through endless ads, pop-ups, and countdowns just to access a simple link. That's why Palku does the work for you.
            </p>
            <p className="text-lg">
              Our bot connects to multiple trusted bypassing APIs to deliver accurate and instant results while keeping your privacy and security at the core of every process. Palku is constantly improving — supporting new link types, enhancing speed, and optimizing performance to ensure a smooth experience for everyone.
            </p>
            <p className="text-lg font-semibold text-foreground">
              Thank you for using Palku. We're here to make your browsing simpler, smarter, and frustration-free.
            </p>
          </div>
        </Card>
      </div>
    </section>
  );
};
