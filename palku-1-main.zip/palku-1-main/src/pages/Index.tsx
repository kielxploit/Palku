import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { WhyChoose } from "@/components/WhyChoose";
import { BotInfo } from "@/components/BotInfo";
import { HowItWorks } from "@/components/HowItWorks";
import { About } from "@/components/About";
import { Privacy } from "@/components/Privacy";
import { FAQ } from "@/components/FAQ";
import { Updates } from "@/components/Updates";
import { Developer } from "@/components/Developer";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background font-['Inter',sans-serif]">
      <Header />
      <main>
        <Hero />
        <WhyChoose />
        <BotInfo />
        <HowItWorks />
        <About />
        <Privacy />
        <FAQ />
        <Updates />
        <Developer />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
